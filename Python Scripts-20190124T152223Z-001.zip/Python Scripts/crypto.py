import pandas 
import numpy
import csv
#Global Variables
infile="E://Ethereum_ExchangeData.csv"

#Read infile into data frame
#data=pandas.read__csv(infile)
print (csv._file_)